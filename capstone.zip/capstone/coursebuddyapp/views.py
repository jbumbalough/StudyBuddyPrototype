from django.shortcuts import render
import sys
from subprocess import run,PIPE

# Create your views here.
def home(request):
    return render(request, 'coursebuddyapp/home.html')

def register(request):
    return render(request, 'coursebuddyapp/register.html')

def login(request):
    return render(request, 'coursebuddyapp/login.html')

def external(request):
    inp1= request.POST.get('p1')
    inp2= request.POST.get('p2')
    inp3= request.POST.get('p3')
    out= run([sys.executable, 'C://Users//Chris//Desktop//capstone//Prototype.py', inp1, inp2, inp3], shell=False, stdout=PIPE, universal_newlines=True)
    return render(request, 'coursebuddyapp/home.html', {'data1':out.stdout})