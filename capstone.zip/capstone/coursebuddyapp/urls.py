from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='coursebuddyapp-home'),
    path('external/', views.external, name='coursebuddyapp-pred'),
    path('register/', views.register, name='coursebuddyapp-register'),
    path('login/', views.login, name='coursebuddyapp-login'),
]
