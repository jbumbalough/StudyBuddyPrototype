from django.apps import AppConfig


class CoursebuddyappConfig(AppConfig):
    name = 'coursebuddyapp'
